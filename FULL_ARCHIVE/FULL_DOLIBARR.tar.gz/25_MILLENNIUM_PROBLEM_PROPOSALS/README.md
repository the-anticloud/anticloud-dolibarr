# 25 Millennium Problem Proposals

**Project:** DOLIBARR
**Upstream:** https://github.com/dolibarr/dolibarr

Content specific to DOLIBARR in category CONSULTANCY.
