# 10 Technical Handoff

**Project:** DOLIBARR
**Upstream:** https://github.com/dolibarr/dolibarr

Content specific to DOLIBARR in category CONSULTANCY.
