# Upstream Provenance

**Project:** `DOLIBARR`
**Category:** CONSULTANCY
**Upstream:** [https://github.com/dolibarr/dolibarr](https://github.com/dolibarr/dolibarr)
**License:** GPL — permissive, repackageable under Anticloud IP

## Upstream Summary

ERP and CRM for consultancy firms

## License Obligation

GPL requires: preserve copyright notice and license text in distributions.
Anticloud adds: Anticommons 0.1.0 for all Anticloud-authored additions.
Upstream code retains its original GPL license.

## Anticloud Additions

All code under `anticloud/`, `pax_integration/`, `aioss/`, and `offline/` directories
is authored by Anticloud FZ LLE and licensed under Anticommons 0.1.0.

## Trade Secret Note

PAX L5 Narrow L2 General 27B internal architecture is proprietary.
The integration API is documented; the model weights are not open-sourced.
