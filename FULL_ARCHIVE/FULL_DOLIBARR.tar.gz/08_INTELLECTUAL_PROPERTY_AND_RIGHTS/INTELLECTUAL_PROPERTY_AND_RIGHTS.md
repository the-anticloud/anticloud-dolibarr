# Intellectual Property and Rights — DOLIBARR

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** DOLIBARR | Category: CONSULTANCY
**Upstream:** https://github.com/dolibarr/dolibarr (GPL)

## Overview

This document covers intellectual property and rights for the Anticloud integration of DOLIBARR.

ERP and CRM for consultancy firms

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into DOLIBARR to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
